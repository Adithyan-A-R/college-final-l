import React from "react";
import styles from "./PriceDetails.module.css";

const PriceDetails = () => {
  return <div>PriceDetails</div>;
};

export default PriceDetails;
