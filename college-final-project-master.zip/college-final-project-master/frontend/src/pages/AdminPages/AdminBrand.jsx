import React from "react";

const AdminBrand = () => {
  return (
    <div>
      <h3>Brands</h3>
      <table>
        <thead>
          <tr>
            <th>No</th>
            <th>Name</th>
            <th>Description</th>
            <th>Status</th>
          </tr>
        </thead>
      </table>
    </div>
  );
};

export default AdminBrand;
