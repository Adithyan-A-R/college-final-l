import React from 'react'

const AdminDashBoard = () => {
  return (
    <div>AdminDashBoard</div>
  )
}

export default AdminDashBoard