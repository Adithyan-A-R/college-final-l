import React from 'react'

const CategoryProductList = () => {
  return (
    <div>CategoryProductList</div>
  )
}

export default CategoryProductList