import React from 'react'

const ProductPage = () => {
  return (
    <div>ProductPage</div>
  )
}

export default ProductPage